### Description
If this is a bug, provide as much information as you can to help reproduce the issue.

### Environment (if bug)

* Octotree version:
* Browser & version:
* OS & version:
* Screenshot, if any (drag an image here)
